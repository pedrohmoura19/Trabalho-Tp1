var class_numero =
[
    [ "getNumero", "class_numero.html#a69925fb8f861b1c9a429bf1141d8ce91", null ],
    [ "setNumero", "class_numero.html#af0abdf8f71a7e556c8942149f0ffb56a", null ]
];