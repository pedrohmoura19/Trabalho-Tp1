var class_taxa =
[
    [ "getTaxa", "class_taxa.html#abb234d96a0d46bdde7ccd5e244e4b020", null ],
    [ "setTaxa", "class_taxa.html#a580263c6991f4ee380f602d19886a7e2", null ]
];