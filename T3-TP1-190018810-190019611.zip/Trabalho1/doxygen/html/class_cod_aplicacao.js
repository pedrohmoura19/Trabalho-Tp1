var class_cod_aplicacao =
[
    [ "getAplicacao", "class_cod_aplicacao.html#a0d163463f88686f5ae7b159627686030", null ],
    [ "setAplicacao", "class_cod_aplicacao.html#aad9800ae85e989a8cec7f6046454137c", null ]
];