var class_prazo =
[
    [ "getPrazo", "class_prazo.html#a46fb711854724a89cc7775596937ec63", null ],
    [ "setPrazo", "class_prazo.html#aa3334052b8be3af3a2b63415f8b25024", null ]
];