var class_senha =
[
    [ "getSenha", "class_senha.html#a8786b3d03b1652e73df1cdce46cbbaaf", null ],
    [ "setSenha", "class_senha.html#a735e4bf5f65cc8d28daa7dbf202fd999", null ]
];