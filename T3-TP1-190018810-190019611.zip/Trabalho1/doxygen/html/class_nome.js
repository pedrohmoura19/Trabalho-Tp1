var class_nome =
[
    [ "getNome", "class_nome.html#aad41176173eec20cbbae1576447a3697", null ],
    [ "setNome", "class_nome.html#ab1507b81047efb89b50b6be0d33c08e5", null ]
];