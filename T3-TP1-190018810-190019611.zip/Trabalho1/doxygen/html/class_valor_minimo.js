var class_valor_minimo =
[
    [ "getValorMinimo", "class_valor_minimo.html#a27357bb48e818896c2e94290e5eb529c", null ],
    [ "setValorMinimo", "class_valor_minimo.html#a7566e97a552024ce6daaff00a29dd68f", null ]
];