var class_cpf =
[
    [ "getCpf", "class_cpf.html#a902324865e17495f9633edd23ed02cd9", null ],
    [ "setCpf", "class_cpf.html#aec03428cfc5f00210ee6442d83d36528", null ]
];