var class_t_u_taxa =
[
    [ "run", "class_t_u_taxa.html#a96c53e3092e7a847fc893645073534c4", null ]
];