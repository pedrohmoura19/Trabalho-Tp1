var searchData=
[
  ['taxa_50',['Taxa',['../class_taxa.html',1,'']]]
];
